
<?php $__env->startSection('admin_content'); ?>
<div class="page-heading">
	<div class="page-title">
		<div class="row">
			<div class="col-12 col-md-6 order-md-1 order-last">
				<h3>Parsell Info</h3>
			</div>
		</div>
	</div>
	<section class="section">
		<div class="card">
			<div class="card-header">
				Simple Datatable
				
			</div>
			<div class="card-body" style="overflow-x:auto;">
				<table class="table table-striped" id="parsell-info">
					<thead>
						<tr>
							<th>ID</th>
							<th>Product Type</th>
							<th>Product cate</th>
							<th>Customer Name</th>
							<th>Customer Phone</th>
							<th>Customer Email</th>
							<th>Customer Address</th>
							<th>Zone</th>
							<th>Area</th>
							<th>Cash amount</th>
							<th>Product Price</th>
							<th>Delivery Type</th>
							<th>Weight</th>
							<th>Action</th>

							
						</tr>
					</thead>
					<tbody>
						
					</tbody>
				</table>
			</div>
		</div>
	</section>
</div>

	

	<div class="modal fade text-left" id="modal-form" tabindex="-1"
		role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width: 50%;"
			role="document">
			<div class="modal-content col-md-12">
				<div class="modal-header">
					<h4 class="modal-title" id="myModalLabel33">Parsell Info </h4>
					<button type="button" class="close" data-bs-dismiss="modal"
					aria-label="Close">
					<i data-feather="x"></i>
					</button>
				</div>
				
				<div class="modal-body">
					<form method="post" enctype="multipart/form-data">
						<?php echo csrf_field(); ?> <?php echo e(method_field('POST')); ?>

                        
						<input type="hidden" name="id" id="id">
					<div class="row">
						<div class="col-md-4">
							<?php 
                            $product_type_id=DB::table('product_types')->get();
                        	?>
							<label>Product Type: </label>
							<select class="form-control" name="product_type_id" id="product_type_id">
                                <option disabled="" selected="">select product type</option>
                                <?php $__currentLoopData = $product_type_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->product_type_name); ?>"><?php echo e($product->product_type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                            </select> 
						</div>

						<div class="col-md-4">
							<?php 
                            $product_cate_id=DB::table('product_categories')->get();
                        	?>
							<label>Product Category: </label>
							<select class="form-control" name="product_cate_id" id="product_cate_id">
                                <option disabled="" selected="">select product category</option>
                                <?php $__currentLoopData = $product_cate_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product_cate->product_category_name); ?>"><?php echo e($product_cate->product_category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                            </select> 
						</div>

						<div class="col-md-4">
							
							<label>Coustomer Name: </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Coustomer Name"
								class="form-control" name="coustomer_name" id="coustomer_name" required>
							</div>
						</div>

						
					</div>
						<div class="row">

						<div class="col-md-4">
							
							<label>Customer Phone: </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Customer Phone"
								class="form-control" name="coustomer_phone" id="coustomer_phone" required>
							</div>
						</div>

						<div class="col-md-4">
							
							<label>Customer Email </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Customer Email"
								class="form-control" name="coustomer_email" id="coustomer_email" required>
							</div>
						</div>

						<div class="col-md-4">
							
							<label>Customer Address: </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Customer Address"
								class="form-control" name="customer_address" id="customer_address" required>
							</div>
						</div>

						</div>

					<div class="row">	

						<div class="col-md-4">
							
							<label>Zone: </label>
							<select class="form-control" name="zone" id="zone">
                                <option disabled="" selected="">select Zone</option>
                                <option value="north">Dhaka North</option>
                                <option value="south">Dhaka South</option>
                                                              
                            </select>
						</div>

						<div class="col-md-4">
							<?php 
	                            $area_info_id=DB::table('area_infos')->get();
	                        ?>
							<label>Area Name: </label>
							<select class="form-control" name="area_id" id="area_id">
                                <option disabled="" selected="">select area</option>
                                <?php $__currentLoopData = $area_info_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($area->area_name); ?>"><?php echo e($area->area_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                            </select> 
                        </div>

                        <div class="col-md-4">
							
							<label>Cash Amount: </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Cash Amount"
								class="form-control" name="cash_amount" id="cash_amount" required>
							</div>
						</div>
						
					</div>

					<div class="row">

						<div class="col-md-4">
							
							<label>Product Price: </label>
							<div class="form-group">
								<input type="text" placeholder="Enter Product Amount"
								class="form-control" name="product_price" id="product_price" required>
							</div>
						</div>

						<div class="col-md-4">
							
							<label>Delivery Type: </label>
							<select class="form-control" name="delivery_type" id="delivery_type">
                                <option disabled="" selected="">select Delivery Type</option>
                                <option value="cod">COD</option>
                                <option value="delivery">Delivery</option>
                                                              
                            </select>
						</div>

						<div class="col-md-4">
							
							<label>Weight: </label>
							<select class="form-control" name="weight" id="weight">
                                <option disabled="" selected="">select weight</option>
                                <option value="500gm">500gm</option>
                                <option value="1kg">1kg</option>
                                                              
                            </select>
							
						</div>
					</div>
					
					<div class="row">
						

						

					</div>

				</div>
				<div class="modal-footer">
					<button type="reset" class="btn btn-light-secondary"
					data-bs-dismiss="modal">Close</button>
					<button type="button" onclick="submitData()" class="btn btn-primary ml-1" id="add-post" 
					></button>
				</div>

				</form>
				
			</div>
		</div>
	</div>



<?php echo $__env->make('layoutfiles.footerfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">

	/*var table1 = $('#parsell-info').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('all.ParsellInfo')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'product_type_name', name: 'product_type_name'},
            {data: 'product_category_name', name: 'product_category_name'},
            {data: 'user_name', name: 'user_name'},
            {data: 'user_type_name', name: 'user_type_name'},
            {data: 'coustomer_name', name: 'coustomer_name'},
            {data: 'coustomer_phone', name: 'coustomer_phone'},
            {data: 'coustomer_email', name: 'coustomer_email'},
            {data: 'customer_address', name: 'customer_address'},
            {data: 'zone', name: 'zone'},
            {data: 'area_id', name: 'area_id'},
            {data: 'cash_amount', name: 'cash_amount'},
            {data: 'product_price', name: 'product_price'},
            {data: 'delivery_type', name: 'delivery_type'},
            {data: 'weight', name: 'weight'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ]
    });*/

    var table1 = $('#parsell-info').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('all.ParsellInfo')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'product_type_id', name: 'product_type_id'},
            {data: 'product_cate_id', name: 'product_cate_id'},
            {data: 'coustomer_name', name: 'coustomer_name'},
            {data: 'coustomer_phone', name: 'coustomer_phone'},
            {data: 'coustomer_email', name: 'coustomer_email'},
            {data: 'customer_address', name: 'customer_address'},
            {data: 'zone', name: 'zone'},
            {data: 'area_id', name: 'area_id'},
            {data: 'cash_amount', name: 'cash_amount'},
            {data: 'product_price', name: 'product_price'},
            {data: 'delivery_type', name: 'delivery_type'},
            {data: 'weight', name: 'weight'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ]
    });
	
	function addForm(){

    	$('input[name_method]').val('POST');
    	$('#modal-form').modal('show');
    	$('#modal-form form')[0].reset();
    	$('.modal-title').text('Add Post')
    	$('#add-post').text('Add Post')
    }

    /*========Insert and Update data===========*/
    function submitData() {

    url = "<?php echo e(url('parsellinfo')); ?>";

    $.ajax({
        url: url,
        type: "POST",
        data: new FormData($("#modal-form form")[0]),
        contentType: false,
        processData: false,
        success: function (data) {
    		console.log(data);
            $('#modal-form').modal('hide');
            table1.ajax.reload();
            /*$('#contact-tables').DataTable().ajax.reload();*/
            swal({
                title: "Success",
                text: "Data Inserted Successfully!",
                icon: "success",
                button: "Great"
            });

        }, error: function (data) {
            swal({
                title: "Oops",
                text: data.message,
                icon: "error",
                timer: '1500'
            });
        }
    });
}

//Edit Data Show By Ajax
    function editParsellInfoData(id) {
        save_method = "edit";
        $('input[name_method]').val('PATCH');
        $('#modal-form form')[0].reset();

        $.ajax({
            url: "<?php echo e(url('parsellinfo')); ?>" + '/' + id + '/edit',
            type: "GET",
            dataType: "JSON",
            success: function (data) {
                $('#modal-form').modal('show');
                $('.modal-title').text(data.coustomer_name + ' ' + 'Edit Information');
                $('#add-post').text("Update Info");
                $('#id').val(data.id);
                $('#product_type_id').val(data.product_type_id);
                $('#product_cate_id').val(data.product_cate_id);
                $('#coustomer_name').val(data.coustomer_name);
                $('#coustomer_phone').val(data.coustomer_phone);
                $('#coustomer_email').val(data.coustomer_email);
                $('#customer_address').val(data.customer_address);
                $('#zone').val(data.zone);
                $('#area_id').val(data.area_id);
                $('#cash_amount').val(data.cash_amount);
                $('#product_price').val(data.product_price);
                $('#delivery_type').val(data.delivery_type);
                $('#weight').val(data.weight);
                
            }, error: function () {
                swal({
                    title: "Oops",
                    text: data.message,
                    icon: "error",
                    timer: '1500'
                });
            }
        }); 
    }

/*=======Show Data By Ajax========*/

   function showParsellInfoData(id){

        $.ajax({
            url: "<?php echo e(url('parsellinfo')); ?>" + '/' + id,
            type: "GET",
            dataType: "JSON",
            success: function (data) {
                $('#modal-form').modal('show');
                $('.modal-title').text(data.user_type_name + ' ' + 'Edit Information');
                $('#add-post').hide();
                $('#id').val(data.id);
                $('#product_type_id').val(data.product_type_id).prop('readonly', true);
                $('#product_cate_id').val(data.product_cate_id).prop('readonly', true);
                $('#coustomer_name').val(data.coustomer_name).prop('readonly', true);
                $('#coustomer_phone').val(data.coustomer_phone).prop('readonly', true);
                $('#coustomer_email').val(data.coustomer_email).prop('readonly', true);
                $('#customer_address').val(data.customer_address).prop('readonly', true);
                $('#zone').val(data.zone).prop('readonly', true);
                $('#area_id').val(data.area_id).prop('readonly', true);
                $('#cash_amount').val(data.cash_amount).prop('readonly', true);
                $('#product_price').val(data.product_price).prop('readonly', true);
                $('#delivery_type').val(data.delivery_type).prop('readonly', true);
                $('#weight').val(data.weight).prop('readonly', true);
                
            }, error: function () {
                swal({
                    title: "Oops",
                    text: data.message,
                    icon: "error",
                    timer: '1500'
                });
            }
        }); 

   }


   //Dalete Data By Ajax
    function deleteParsellInfoData(id) {
        var csrf_token = $('meta[name="csrf-token"]').attr('content');
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url: "<?php echo e(url('parsellinfo')); ?>" + '/' + id,
                    type: "POST",
                    data: {'_method': 'DELETE', '_token': csrf_token},
                    success: function (data) {
                    	table1.ajax.reload();
                        /*$('#contact-tables').DataTable().ajax.reload();*/
                        swal({
                            title: "Delete Done",
                            text: "Poof! Your data file has been deleted!",
                            icon: "success",
                            button: "Done"
                        });
                    }, error: function () {
                        swal({
                            title: "Opps...",
                            text: data.message,
                            icon: "error",
                            button: '5000',
                        });
                    }
                });
            } else {
                swal("Your imaginary file is safe!");
            }
        });

    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/godelive/public_html/resources/views/dashboard/parsell_info.blade.php ENDPATH**/ ?>