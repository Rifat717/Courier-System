<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_info extends Model
{
    //
}
