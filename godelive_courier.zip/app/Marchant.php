<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marchant extends Model
{
    //
}
