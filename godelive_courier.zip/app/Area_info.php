<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area_info extends Model
{
    //
}
