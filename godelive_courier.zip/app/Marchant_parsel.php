<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Marchant_parsel extends Model
{
    //
}
